===============================
Project:  UploadImg
Released: Sept 3rd, 2002
Version:  1.0
===============================

Purpose: This project demonstrates how to use Delphi to upload an image to the Zoovy 
Image Library using the standard rfc 1867 protocol. This code uses https and ssl to 
send the image securely (since username and password are passed - the data must be secure).

This project was designed to run on Delphi 5. 
This requires Delphi Internet Direct (Indy) and SSL DLLs:


Indy URL: 
	http://www.nevrona.com/indy

SSL DLL URL: 
	http://www.intelicom.si/download.php and click on Indy

Note: The dlls must be installed in the same directory as the generated exe. 
If the dlls are not right directory, the ssl connection will not work properly.

If you suspect the problem is with openSSL then you can probably disable the SSL intercept
and access Zoovy over HTTP as well.

--------------------------------------------------------------------------------
Copyright 2002 by Zoovy, Inc.  