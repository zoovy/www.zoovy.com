* Contents *

src - individual .js classes that comprise the build .js
 
build - production source file
 |
  -- name_of_component.js - the fully commented, production source.
 |
  -- YAHOO.js - YAHOO namespace file.
 
docs - the jsdoc output of the build file
 |
  -- index.html - the documentation entry page
  
examples - functional implementations of the component.
 |  
  -- index.html - the entry page listing all functional examples.
  
  
